# input

# variable declaration

package_Price = 99.00
quantity = 0.0
discount = 0.0
pre_discount_amount = 0.0
discount_amount = 0.0
total_amount = 0.0

# prompt the user for the quantity of packages

quantity = int(input('Enter the number of packages purchased: '))

# determine the quantity discount

if quantity > 99:
    discount = 0.40
elif quantity >= 50:
    discount = 0.30
elif quantity >= 20:
    discount = 0.20
else:
    if quantity >= 10:
        discount = 0.10


# processing
# calculate the total amount before the discount
pre_discount_amount = quantity * package_Price


# calculate the discount amount
discount_amount = pre_discount_amount * discount


# calculate the total amount including the discount
total_amount = pre_discount_amount - discount_amount


# output
# display the discount amount and total amount

print('Discount Amount: $',format(discount_amount,'.2f'))
print('Total Amount: $',format(total_amount,'.2f'))

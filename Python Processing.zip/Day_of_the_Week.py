# Pseudo Code

# ask the user for a number
# save input to number
# if the number is within range, print the day of the week
# if it is not, print an error message


# input

# prompt the user for a number

number = int(input('Enter a number: '))

# Determine the day of the week

if number == 1:
    print('Monday')
elif number == 2:
    print('Tuesday')
elif number == 3:
    print('Wednesday')
elif number == 4:
    print('Thursday')
elif number == 5:
    print('Friday')
elif number == 6:
    print('Saturday')
elif number == 7:
    print('Sunday')
else:
    print('ERROR: only numbers 1-7 are accepted.')
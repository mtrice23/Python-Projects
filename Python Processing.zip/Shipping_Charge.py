 # Pseudo Code

# declare the weight_of_package variable
# declare the shipping_cost variable
# ask the user for the weight of the package
# save input to weight_of_package
# determine the shipping cost based on the weight of the package
# print the shipping charge


# variable declaration

weight_of_package = 0.0

shipping_cost = 0.0

shipping_charge = 0.0

# input
# prompt the user for the weight of the package

weight_of_package = float(input('Enter the weight of the package: '))

# determine the shipping cost based on the weight of the package

if weight_of_package <= 2:
    shipping_cost = 1.50
elif weight_of_package <= 6:
    shipping_cost = 3.00
elif weight_of_package <= 10:
    shipping_cost = 4.00
else:
    shipping_cost = 4.75


# processing
# calculate the shipping charge

shipping_charge = weight_of_package * shipping_cost


# Output
# Display the shipping charges

print('The shipping cost is $',format(shipping_cost,',.2f'))
print('The shipping charge is $',format(shipping_charge,',.2f'))

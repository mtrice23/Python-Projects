# Pseudo Code

# declare the rectangle1_length variable
# declare the rectangle1_width variable
# declare the rectangle2_length variable
# declare the rectangle2_width variable
# declare the rectangle1_area
# declare the rectangle2_area
# ask the user for the length and width of rectangle 1
# save the input to rectangle1_length & rectangle1_width respectively
# ask the user for the length and width of rectangle 2
# save the input to rectangle2_length & rectangle2_width respectively
# calculate the area of rectangle 1 & rectangle 2
# print which rectangle has the greater area
# if the area of both rectangles are equal,
# print "the area of rectangle 1 & rectangle 2 are equal"


# Variable Declaration

Rectangle1_Length = 0.0
Rectangle1_Width = 0.0
Rectangle2_Length = 0.0
Rectangle2_Width = 0.0
Rectangle1_Area = 0.0
Rectangle2_Area = 0.0


# input

# prompt the user for the length of rectangle1

Rectangle1_Length = float(input('Enter the length of rectangle 1: '))

# prompt the user for the width of rectangle1

Rectangle1_Width = float(input('Enter the width of rectangle 1: '))

# prompt the user for the length of rectangle2

Rectangle2_Length = float(input('Enter the length of rectangle 2: '))

# prompt the user for the width of rectangle2

Rectangle2_Width = float(input('Enter the width of rectangle 2: '))


# processing

# calculate the area of rectangle1 & rectangle2

Rectangle1_Area = Rectangle1_Length * Rectangle1_Width

Rectangle2_Area = Rectangle2_Length * Rectangle2_Width


# determine and display the rectangle with the greater area

if Rectangle1_Area > Rectangle2_Area:
    print('Rectangle 1 has the greater area.')
elif Rectangle2_Area > Rectangle1_Area:
    print('Rectangle 2 has the greater area.')
else:
    print('The area of Rectangle 1 and Rectangle 2 are equal.')
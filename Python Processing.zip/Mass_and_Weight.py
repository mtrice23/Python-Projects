# Pseudo Code

# declare the mass variable
# ask the user for the mass of the object
# save the input to mass
# calculate the weight of the object based on the mass
# print the weight
# if the weight of the object is more than 500 newtons,
# print "The object is too heavy."
# if the weight of the object is less than 100 newtons,
# print "The object is too light."


# Variable Declaration

mass = 0.0
weight = 0.0


# input

# prompt the user for the mass

mass = float(input('Enter the mass of the object: '))


# Processing

# calculate the weight of the object

weight = mass * 9.8


# Output

# determine the weight of the object

if weight > 500:
    print('The object is too heavy.')
elif weight < 100:
    print('The object is too light')
else:
    print('The weight is:',weight,'newtons')

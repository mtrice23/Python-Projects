# main def
def main():
    # initialize variables for bugs and
    # total number of bugs collected
    bugs = 0
    answer = 'y'



    answer = 'y'
    answer = input('Do you want to enter bugs collected for a week? (y)')
    while answer == 'y':
        # print bugs collected
        getBugs(bugs)
        answer = input('Do you want to record week')

def getBugs(bugs):
    # get number of bugs collected each day
    total = 0
    for day in range(5):
        bugs = int(input('Enter the number of bugs collected on day {}: '.format(day + 1)))
        total += int(bugs)

        # Display the total number of bugs collected

    print('Total bugs collected:',total)

# call the main function
main()
# define the main function

def main():
    # declare the local variables
    score1 = 0
    score2 = 0
    score3 = 0
    score4 = 0
    score5 = 0
    avg = 0

    # prompt user to input test scores

    score1 = float(input('Enter score 1: '))
    score2 = float(input('Enter score 2: '))
    score3 = float(input('Enter score 3: '))
    score4 = float(input('Enter score 4: '))
    score5 = float(input('Enter score 5: '))

    # get the average for the scores entered by the user

    findavg = calc_average(score1,score2,score3,score4,score5)

    # display the letter grade for each score entered by the user
    grade = determine_grade(findavg)


    print('score\t\tnumeric grade\tletter grade')
    print('----------------------------------------------------')
    print('score 1:\t', score1, '\t\t',determine_grade(score1) )
    print('score 2:\t', score2, '\t\t',determine_grade(score2) )
    print('score 3:\t', score3, '\t\t',determine_grade(score3) )
    print('score 4:\t', score4, '\t\t',determine_grade(score4) )
    print('score 5:\t', score5, '\t\t',determine_grade(score5) )

    print('----------------------------------------------------')
    print ('Average score:\t',findavg    , '\t\t',determine_grade(findavg)   )

# define the calc_average function

def calc_average(score1,score2,score3,score4,score5):
    scores = score1+score2+score3+score4+score5
    avg = scores / 5
    return avg

# define the determine_grade function

def determine_grade(findavg):
    if findavg >= 90:
        grade = 'A'
        return grade
    elif findavg >= 80:
        grade = 'B'
        return grade
    elif findavg >= 70:
        grade = 'C'
        return grade
    elif findavg >= 60:
        grade = 'D'
        return grade
    else:
        grade = 'F'
        return grade

# call the main function

main()
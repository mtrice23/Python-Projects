# define the main function

def main():

    # declare the local variables

    fat_grams = 0.0
    carbohydrates = 0.0
    calories_fat = 0.0
    carlories_carbs = 0.0

    # prompt user to enter the number of fat grams
    fat_grams = float(input('Enter the number of fat grams consumed: '))
    carbohydrates = float(input('Enter the number of carbohydrate grams consumed: '))

    # calculate the calories from fat
    find_calories1 = calc_fat (fat_grams)

    # next calculate the calories from carbohydrates
    find_calories2 = calc_carb (carbohydrates)

    print('Grams of fat: ',format(fat_grams,'.2f'))
    print('Calories of fat: ',format(calc_fat(fat_grams),'.2f'))
    print('Grams of carbo: ',format(carbohydrates,'.2f'))
    print('Calories of carbo: ',format(calc_carb(carbohydrates),'.2f'))


def calc_fat(fat_grams):
    calories_fat = fat_grams * 9
    return calories_fat


def calc_carb(carbohydrates):
    calories_carbs = carbohydrates * 4
    return calories_carbs

# call main function
main()
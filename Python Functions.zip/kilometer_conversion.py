# Global Variables
KILOMETERS_TO_MILES = 0.6214

def main():

    kilometers = 0.0

    # prompt user for distance in kilometers
    kilometers = float(input('Enter the distance in kilometers: '))

    showMiles(kilometers)



def showMiles(kilometers):
    # Declare local variables
    miles = 0.0


    miles = kilometers * KILOMETERS_TO_MILES
    print('The conversion of',format(kilometers,'.2f'),'Kilometers')
    print('is',format(miles,'.2f'),'Miles')

main()
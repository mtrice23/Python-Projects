import random

# main function
def main():
    # local variables

    num1 = 0
    num2 = 0
    userAnswer = 0
    correctAnswer = 0

    # generate numbers
    num1 = random.randint(0, 10)
    num2 = random.randint(0, 10)

    # display the problem
    displayProblem(num1,num2)

    # get user answer
    userAnswer = getUserAnswer()

    # calculate correct answer

    correctAnswer = num1+num2

    # display the results
    showResult(correctAnswer, userAnswer)

def showResult(correctAnswer, userAnswer):
    if correctAnswer == userAnswer:
        print('Correct!')
    else:
        print('Incorrect!')

def getUserAnswer():
    inputAnswer = int(input('Enter the answer: '))
    return inputAnswer


def displayProblem(num1,num2):
    print(format(num1, '5'))
    print('+', end='')
    print(format(num2, '4'))
    print('=========')

# call the main functiion
main()
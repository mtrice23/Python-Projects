
def main():
    answer = 'y'
    while answer == 'y' or answer == 'Y':
        # local variables
        length = 0.0 # to hold the rectangle's length
        width = 0.0 # to hold the rectangle's width
        area = 0.0 # to hold the rectangle's area

        # get the length
        Length = getLength()
        print('Length:',Length)

        # get the width
        Width = getWidth()
        print('Width:',Width)

        # get the area
        Area = calcArea(Length, Width)

        # display results
        Display = showResults(Area)
        print('The area will return as: ',Area)
        answer = input('Would you like to continue? (Y/y)')

def getLength():
        length = 0.0
        print('Enter the length of the rectangle: ', end='')
        length = float(input())
        return length

def getWidth():
        width = 0.0
        print('Enter the width of the rectangle: ', end='')
        width = float(input())
        return width

def calcArea(length, width):
        area = 0.0
        area = length * width
        return area

def showResults(Area):
    return Area

# call main
main()
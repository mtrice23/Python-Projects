
def main():
    # Display the menu
    choice = 1

    # get the menu
    Options = getMenu(choice)


def getMenu(choice):

    while choice != 5:
        print('Math Tutor Menu')
        print('1 - Addition')
        print('2 - Subtraction')
        print('3 - Multiplication')
        print('4 - Division')
        print('5 - Quit')
        print('Enter your choice (1-5)', end='')
        choice = int(input())

        if choice == 1:
            print('\nAddition Under Construction\n')
        elif (choice == 2):
            print('\nSubtraction Under Construction\n')
        elif (choice == 3):
            print('\nMultiplication Under Construction\n')
        elif (choice == 4):
            print('\nDivision Under Construction\n')
        elif (choice == 5):
            print('\nThanks for playing\n')
        else:
            print('Only numbers (1-5) are valid')

# call the main
main()
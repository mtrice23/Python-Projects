# main function

def main():


     feet = 0.0
     inches = 0.0

     # get the number of feet from the user
     feet = float(input('Enter the number of feet: '))

     # display the number of inches
     inches = feet_to_inches(feet)
     print(feet, 'feet =',inches,'inches')

def feet_to_inches(feet):
    return 12 * feet

main()
bugs_collected = 0
total_bugs = 0


for i in range(5):
    bugs_collected = int(input('Enter the number of bugs collected: '))
    total_bugs += bugs_collected

print('The total number of bugs collected:', total_bugs)


CALORIES_PER_MINUTE = 4.2

TOTAL_CALORIES = 0.0

print('Minutes   \tCalories Burned')
print('------------------------------')


for i in range(10,35,5):
    if CALORIES_PER_MINUTE == 4.2:
        TOTAL_CALORIES = CALORIES_PER_MINUTE*i
    print(i,'         \t',TOTAL_CALORIES)

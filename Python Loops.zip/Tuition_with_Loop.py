# input

tuition = 8000

increase = .03

tuition_increase = tuition * increase

print('Year\tTuition')
print('--------------------')
for i in range(1, 6):
    if increase == .03:
        tuition += tuition_increase
    print(i,'    \t','$',format(tuition,',.0f'),sep='')
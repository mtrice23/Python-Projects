# variables
bugs_collected = 0
total_bugs = 0
days = ('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday')

for i in days:
    bugs_collected = int(input('Enter the number of bugs collected on {}: '.format(i)))
    total_bugs += bugs_collected
print('Total Bugs:',total_bugs)
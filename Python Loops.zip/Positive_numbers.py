# Pseudo Code

# declare the numbers entered variable as 'number'
# declare the total amount of numbers entered as variable as 'total'
# ask the user to enter a positive number(loop)
# continue until the user enters a negative number
# print the 'total'


# variable declaration

number = 0
total = 0

# input

# prompt the user to enter a positive number
# this will continue until the user enters a negative number

print('This is a program that prompts the user to enter a positive number. Enter a negative')
print('number to end the program and calculate the sum of all positive numbers entered.')

while True:
    number=int(input('Enter a positive number: '))
    if (number % 2)==0:
        total+=number
    else:
        break

# display the sum of all positive numbers entered

print('Sum:', total)

# This program will identify a type of triangle based on the length of its sides
# i've created the 'answer' variable to control the loop

answer = 'y'

# prompt the user to enter the length of 3 sides of a triangle

while answer == 'y':
    print("Identify the type of triangle based on the lengths of it's side")
    a = float(input("Enter side A"))
    b = float(input('Enter side B'))
    c = float(input("Enter side C"))

# determines if the length of each side entered forms a triangle

    if a < 1 or b < 1 or c < 1:
        print("These side do not form a triangle")
        print("All side must be greater than zero")
    elif a >= b + c or b >= a + c or c >= a + b:
        print("This is not triangle because the sum of the\ntwo smaller sides is not greater than the largest side.")

# if so, identifies the type of triangle formed

    elif a == b == c:
        print("It is ")
        print("an equilateral triangle because all sides are equal.")
    elif a == b or b == c or c == a:
        print("It is ")
        print("an isosceles triangle because exactly two sides are equal.")
    else:
        print("It is ")
        print("a scalene triangle because no sides are equal.")

# See if user wants to enter another set of lengths
    answer = input("Do you want to continue? Y/y")
